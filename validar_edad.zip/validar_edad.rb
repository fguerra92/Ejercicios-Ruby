def validar_edad(edad)
    puts edad
    if edad >= 18
    puts "Es mayor de edad"
    else
    puts "Es menor de edad"
    end
end


validar_edad(rand(100))
validar_edad(rand(100))
validar_edad(rand(100))