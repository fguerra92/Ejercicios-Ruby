numero = ARGV[0].to_i
numero.times do |i|
puts "Iteración #{i}"
end